package BIEOtag;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import fileReadAndWrite.fileRead;
import fileReadAndWrite.fileWrite;

public class tagBIEO {

	static class interval {

		int min;
		int max;
		int length;

		public int getLength() {
			return length;
		}

		public void setLength() {
			this.length = this.max - this.min + 1;
		}

		public interval(int min, int max) {
			// TODO Auto-generated constructor stub
			this.min = min;
			this.max = max;
			setLength();
		}

		public int getMin() {
			return min;
		}

		public void setMin(int min) {
			this.min = min;
		}

		public int getMax() {
			return max;
		}

		public void setMax(int max) {
			this.max = max;
		}
	}

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		// tag("BIEO/bstd.txt", "BIEO/tag/bstdBIEO.txt");
		// tag("BIEO/xyqk.txt", "BIEO/tag/xyqkBIEO.txt");
		// tag("BIEO/ybxm.txt", "BIEO/tag/ybxmBIEO.txt");
		// tag("BIEO/zljg.txt", "BIEO/tag/zljgBIEO.txt");

		tag("BIEO/split/originWithoutSpaceDisorganise.txt", "BIEO/split/originWithoutSpaceDisorganise.txt");
	}

	public static void tag(String input, String output) throws IOException {

		BufferedReader bReader = new fileRead().readFile(input);
		BufferedWriter bWriter = new fileWrite().writeFile(output);

		BufferedReader DiseaseAndDiagnosisReader = new fileRead().readFile("result/DiseaseAndDiagnosis.txt");
		BufferedReader inspectionReader = new fileRead().readFile("result/inspection.txt");
		BufferedReader SymptomsandsignsReader = new fileRead().readFile("result/Symptomsandsigns.txt");
		BufferedReader treatReader = new fileRead().readFile("result/treat.txt");

		ArrayList<String> dList = new ArrayList<>();
		ArrayList<String> iList = new ArrayList<>();
		ArrayList<String> sList = new ArrayList<>();
		ArrayList<String> tList = new ArrayList<>();

		String aLine = null;
		while ((aLine = DiseaseAndDiagnosisReader.readLine()) != null)
			dList.add(aLine);
		DiseaseAndDiagnosisReader.close();

		while ((aLine = inspectionReader.readLine()) != null)
			iList.add(aLine);
		inspectionReader.close();

		while ((aLine = SymptomsandsignsReader.readLine()) != null)
			sList.add(aLine);
		SymptomsandsignsReader.close();

		while ((aLine = treatReader.readLine()) != null)
			tList.add(aLine);
		treatReader.close();

		int dBegin = 0, dEnd = 0, iBegin = 0, iEnd = 0, sBegin = 0, sEnd = 0, tBegin = 0, tEnd = 0;

		int coverCount = 0;// 重叠的区间数目
		int overlapCount = 0;// 交叉的区间数目
		Map<interval, Integer> map = new HashMap<>();

		while ((aLine = bReader.readLine()) != null) {
			String[] terms = aLine.split(",", -1);

			for (String term : terms) {
				dBegin = dEnd = iBegin = iEnd = sBegin = sEnd = tBegin = tEnd = 0;
				for (String d : dList) {
					if (term.contains(d)) {
						dBegin = term.indexOf(d);
						dEnd = dBegin + d.length() - 1;
					}
				}

				for (String i : iList) {
					if (term.contains(i)) {
						iBegin = term.indexOf(i);
						iEnd = iBegin + i.length() - 1;
					}
				}

				for (String s : sList) {
					if (term.contains(s)) {
						sBegin = term.indexOf(s);
						sEnd = sBegin + s.length() - 1;
					}
				}

				for (String t : tList) {
					if (term.contains(t)) {
						tBegin = term.indexOf(t);
						tEnd = tBegin + t.length() - 1;
					}
				}

				String[] bieo = new String[term.length() + 1];
				bieo[term.length()] = "eos";
				for (int i = 0; i < term.length(); i++)
					bieo[i] = "O";

				// 先判断有没有重叠的，如果有的话取最长的那一个
				interval dint = new interval(dBegin, dEnd);
				interval iint = new interval(iBegin, iEnd);
				interval sint = new interval(sBegin, sEnd);
				interval tint = new interval(tBegin, tEnd);

				map = compare(dint, iint);
				interval dOrI = null;
				for (interval key : map.keySet()) {
					dOrI = key;
					overlapCount = overlapCount + map.get(dOrI);
				}
				if (dOrI.length == dint.length) {
					coverCount++;
					interval dOrS = null;
					map = compare(dint, sint);
					for (interval key : map.keySet()) {
						dOrS = key;
						overlapCount = overlapCount + map.get(dOrS);
					}
					if (dOrS.length == dint.length) {
						coverCount++;
						interval dOrT = null;
						map = compare(dint, tint);
						for (interval key : map.keySet()) {
							dOrT = key;
							overlapCount = overlapCount + map.get(dOrT);
						}
						if (dOrT.length == dint.length) {
							coverCount++;
						} else if (dOrT.length == tint.length) {
							coverCount++;
						} else {
							;
						}
					} else if (dOrS.length == sint.length) {
						coverCount++;
						interval sOrT = null;
						map = compare(sint, tint);
						for (interval key : map.keySet()) {
							sOrT = key;
							overlapCount = overlapCount + map.get(sOrT);
						}
						if (sOrT.length == sint.length) {
							coverCount++;
						} else if (sOrT.length == tint.length) {
							coverCount++;
						} else {
							;
						}
					} else {
						interval dOrT = null;
						map = compare(dint, tint);
						for (interval key : map.keySet()) {
							dOrT = key;
							overlapCount = overlapCount + map.get(dOrT);
						}
						if (dOrT.length == dint.length) {
							coverCount++;
						} else if (dOrT.length == tint.length) {
							coverCount++;
						} else {
							;
						}

						interval sOrT = null;
						map = compare(sint, tint);
						for (interval key : map.keySet()) {
							sOrT = key;
							overlapCount = overlapCount + map.get(sOrT);
						}
						if (sOrT.length == sint.length) {
							coverCount++;
						} else if (sOrT.length == tint.length) {
							coverCount++;
						} else {
							;
						}
					}
				} else if (dOrI.length == iint.length) {
					coverCount++;
					interval iOrS = null;
					map = compare(iint, sint);
					for (interval key : map.keySet()) {
						iOrS = key;
						overlapCount = overlapCount + map.get(iOrS);
					}
					if (iOrS.length == iint.length) {
						coverCount++;
						interval iOrT = null;
						map = compare(iint, tint);
						for (interval key : map.keySet()) {
							iOrT = key;
							overlapCount = overlapCount + map.get(iOrT);
						}
						if (iOrT.length == iint.length) {
							coverCount++;
						} else if (iOrT.length == tint.length) {
							coverCount++;
						} else {
							;
						}
					} else if (iOrS.length == sint.length) {
						coverCount++;
						interval sOrT = null;
						map = compare(sint, tint);
						for (interval key : map.keySet()) {
							sOrT = key;
							overlapCount = overlapCount + map.get(sOrT);
						}
						if (sOrT.length == sint.length) {
							coverCount++;
						} else if (sOrT.length == tint.length) {
							coverCount++;
						} else {
							;
						}
					} else {
						interval iOrT = null;
						map = compare(iint, tint);
						for (interval key : map.keySet()) {
							iOrT = key;
							overlapCount = overlapCount + map.get(iOrT);
						}
						if (iOrT.length == iint.length) {
							coverCount++;
						} else if (iOrT.length == tint.length) {
							coverCount++;
						} else {
							;
						}

						interval sOrT = null;
						map = compare(sint, tint);
						for (interval key : map.keySet()) {
							sOrT = key;
							overlapCount = overlapCount + map.get(sOrT);
						}
						if (sOrT.length == sint.length) {
							coverCount++;
						} else if (sOrT.length == tint.length) {
							coverCount++;
						} else {
							;
						}
					}
				} else {
					interval dOrS = null;
					map = compare(dint, sint);
					for (interval key : map.keySet()) {
						dOrS = key;
						overlapCount = overlapCount + map.get(dOrS);
					}
					if (dOrS.length == dint.length) {
						coverCount++;
						interval dOrT = null;
						map = compare(dint, tint);
						for (interval key : map.keySet()) {
							dOrT = key;
							overlapCount = overlapCount + map.get(dOrT);
						}
						if (dOrT.length == dint.length) {
							coverCount++;
						} else if (dOrT.length == tint.length) {
							coverCount++;
						} else {
							;
						}
					} else if (dOrS.length == sint.length) {
						coverCount++;
						interval sOrT = null;
						map = compare(sint, tint);
						for (interval key : map.keySet()) {
							sOrT = key;
							overlapCount = overlapCount + map.get(sOrT);
						}
						if (sOrT.length == sint.length) {
							coverCount++;
						} else if (sOrT.length == tint.length) {
							coverCount++;
						} else {
							;
						}
					} else {
						interval dOrT = null;
						map = compare(dint, tint);
						for (interval key : map.keySet()) {
							dOrT = key;
							overlapCount = overlapCount + map.get(dOrT);
						}
						if (dOrT.length == dint.length) {
							coverCount++;
						} else if (dOrT.length == tint.length) {
							coverCount++;
						} else {
							;
						}

						interval sOrT = null;
						map = compare(sint, tint);
						for (interval key : map.keySet()) {
							sOrT = key;
							overlapCount = overlapCount + map.get(sOrT);
						}
						if (sOrT.length == sint.length) {
							coverCount++;
						} else if (sOrT.length == tint.length) {
							coverCount++;
						} else {
							;
						}
					}

					interval iOrS = null;
					map = compare(iint, sint);
					for (interval key : map.keySet()) {
						iOrS = key;
						overlapCount = overlapCount + map.get(iOrS);
					}
					if (iOrS.length == iint.length) {
						coverCount++;
						interval iOrT = null;
						map = compare(iint, tint);
						for (interval key : map.keySet()) {
							iOrT = key;
							overlapCount = overlapCount + map.get(iOrT);
						}
						if (iOrT.length == iint.length) {
							coverCount++;
						} else if (iOrT.length == tint.length) {
							coverCount++;
						} else {
							;
						}
					} else if (iOrS.length == sint.length) {
						interval sOrT = null;
						map = compare(sint, tint);
						for (interval key : map.keySet()) {
							sOrT = key;
							overlapCount = overlapCount + map.get(sOrT);
						}
						if (sOrT.length == sint.length) {
							coverCount++;
						} else if (sOrT.length == tint.length) {
							coverCount++;
						} else {
							;
						}
					} else {
						interval iOrT = null;
						map = compare(iint, tint);
						for (interval key : map.keySet()) {
							iOrT = key;
							overlapCount = overlapCount + map.get(iOrT);
						}
						if (iOrT.length == iint.length) {
							coverCount++;
						} else if (iOrT.length == tint.length) {
							coverCount++;
						} else {
							;
						}

						interval sOrT = null;
						map = compare(sint, tint);
						for (interval key : map.keySet()) {
							sOrT = key;
							overlapCount = overlapCount + map.get(sOrT);
						}
						if (sOrT.length == sint.length) {
							coverCount++;
						} else if (sOrT.length == tint.length) {
							coverCount++;
						} else {
							;
						}
					}
				}

				if (dint.min == 0 && dint.max == 0) {
					;
				} else if (dint.length == 1) {
					bieo[dint.min] = "Sd";
				} else {
					bieo[dint.min] = "Bd";
					bieo[dint.max] = "Ed";
					for (int i = dint.min + 1; i < dint.max; i++)
						bieo[i] = "Id";
				}

				if (iint.min == 0 && iint.max == 0)
					;
				else if (iint.length == 1) {
					bieo[iint.min] = "Si";
				} else {
					bieo[iint.min] = "Bi";
					bieo[iint.max] = "Ei";
					for (int i = iint.min + 1; i < iint.max; i++)
						bieo[i] = "Ii";
				}

				if (sint.min == 0 && sint.max == 0)
					;
				else if (sint.length == 1) {
					bieo[sint.min] = "Ss";
				} else {
					bieo[sint.min] = "Bs";
					bieo[sint.max] = "Es";
					for (int i = sint.min + 1; i < sint.max; i++)
						bieo[i] = "Is";
				}

				if (tint.min == 0 && tint.max == 0)
					;
				else if (tint.length == 1) {
					bieo[tint.min] = "St";
				} else {
					bieo[tint.min] = "Bt";
					bieo[tint.max] = "Et";
					for (int i = tint.min + 1; i < tint.max; i++)
						bieo[i] = "It";
				}

				for (String word : bieo)
					bWriter.write(word + " ");
				bWriter.write("\n");

			}
		}
		System.out.println(coverCount + "\t" + overlapCount);
		bWriter.close();
	}

	// 判断两个区间是否重叠，重叠的话返回跨度长的那一个，然后将短的那一个的min和max置0，不重叠返回int3
	public static Map<interval, Integer> compare(interval int1, interval int2) {

		interval int3 = new interval(1000, 2000);
		int overlapFlag = 0;
		Map<interval, Integer> map = new HashMap<>();

		// int1或int2没有匹配到的情况
		if ((int1.min == 0 && int1.max == 0) || (int2.min == 0 && int2.max == 0)) {
			map.put(int3, overlapFlag);
			return map;
		}
		// 判断是否有重叠
		else {
			int begin = 0, end = 0;
			if (int1.min > int2.min)
				begin = int1.min;
			else {
				begin = int2.min;
			}

			if (int1.max < int2.max)
				end = int1.max;
			else {
				end = int2.max;
			}

			int length = end - begin;
			if (length >= 0) {
				if (int1.length > int2.length) {
					// 判断是重叠还是交叉
					if ((int1.min > int2.min && int1.min < int2.max && int1.max > int2.max)
							|| (int2.min > int1.min && int2.min < int1.max && int2.max > int1.max)) {
						overlapFlag = 1;
						map.put(int1, overlapFlag);
						int2.min = 0;
						int2.max = 0;
						return map;
					} else {
						map.put(int1, overlapFlag);
						int2.min = 0;
						int2.max = 0;
						return map;
					}
				} else {
					if ((int1.min > int2.min && int1.min < int2.max && int1.max > int2.max)
							|| (int2.min > int1.min && int2.min < int1.max && int2.max > int1.max)) {
						overlapFlag = 1;
						map.put(int2, overlapFlag);
						int1.min = 0;
						int1.max = 0;
						return map;
					} else {
						map.put(int1, overlapFlag);
						int1.min = 0;
						int1.max = 0;
						return map;
					}
				}
			} else {
				map.put(int3, overlapFlag);
				return map;
			}
		}
	}
}
