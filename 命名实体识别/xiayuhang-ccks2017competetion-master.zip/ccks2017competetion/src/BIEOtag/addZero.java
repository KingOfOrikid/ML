package BIEOtag;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import fileReadAndWrite.fileRead;
import fileReadAndWrite.fileWrite;

//给打完BIEO标签的数据补0，即长度较短的在后面补0,使所有字符串长度相同
public class addZero {

	public static void main(String[] args) throws IOException {
		mostLengthNumber("tag/tagBIEO.txt");
		addZeroAndCutOff("tag/tagBIEO.txt", "tag/tagBIEOAddZero.txt");
	}

	// 统计出现次数最多的字符串长度
	public static void mostLengthNumber(String input) throws IOException {
		BufferedReader bReader = new fileRead().readFile(input);
		Map<Integer, Integer> map = new HashMap<>();
		String aline = null;
		while ((aline = bReader.readLine()) != null) {
			String[] terms = aline.split(" ");
			int length = terms.length;
			if (map.get(length) != null) {
				map.put(length, map.get(length) + 1);
			} else {
				map.put(length, 1);
			}
		}

		int most = 0;// 次数
		int mostLength = 0;// 出现最多的长度
		for (Integer x : map.keySet()) {
			System.out.println(x + "\t" + map.get(x));
			if (map.get(x) > most) {
				mostLength = x;
				most = map.get(x);
			}
		}
		System.out.println(mostLength + "\t" + most);
	}
	
	// 补0与截断代码
	// 参数：bstd:20;xyqk:20；ybxm：12
	public static void addZeroAndCutOff(String input,String output) throws IOException{
		BufferedReader bReader = new fileRead().readFile(input);
		BufferedWriter bWriter = new fileWrite().writeFile(output);
		String aline = null;
		while ((aline = bReader.readLine()) != null) {
			String[] terms = aline.split(" ");
			if (terms.length < 20) {
				int length = terms.length;
				for (int i = length; i < 20; i++) {
					aline = aline + " 0";
				}
			} else {
				aline = "";
				for (int i = 0; i < 19; i++) {
					aline = aline + terms[i] + " ";
				}
				aline = aline + "eos";
			}
			bWriter.write(aline + "\n");
		}
		bWriter.close();
	}

}
