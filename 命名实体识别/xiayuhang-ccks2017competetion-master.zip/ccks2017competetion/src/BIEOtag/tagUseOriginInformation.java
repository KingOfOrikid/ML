package BIEOtag;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import fileReadAndWrite.fileRead;
import fileReadAndWrite.fileWrite;
import splitStringAddSpace.splitSource;
/** 
* @author 夏宇航 xiayuhang_ecust@qq.com: 
* @version 创建时间：2017年6月27日 上午10:49:50 
* 类说明 
*/

//正式使用的标注代码
//使用给定的训练数据进行打标签

public class tagUseOriginInformation {

	public static void main(String[] args) throws IOException {

		/********************************************* 原始训练数据处理**************************************************************************/
//		tag("CCKS 2017 Task2/01-一般项目/一般项目-", "tag/一般项目.txt",300);
//		tag("CCKS 2017 Task2/02-病史特点/病史特点-", "tag/病史特点.txt",300);
//		tag("CCKS 2017 Task2/04-诊疗经过/诊疗经过-", "tag/诊疗经过.txt",300);
//		tag("CCKS 2017 Task2/05-出院情况/出院情况-", "tag/出院情况.txt",300);
//
//		mergeFile("tag/一般项目.txt", "tag/病史特点.txt", "tag/诊疗经过.txt", "tag/出院情况.txt", "tag/merge.txt");

		// 将合并后的文件按。分割成短句，字与字之间不添加空格
//		splitSource.splitNoSpace("tag/merge.txt", "tag/mergeSplit.txt");

		// 判断有多少特征重叠
//		overlap("CCKS 2017 Task2/01-一般项目/一般项目-");
//		overlap("CCKS 2017 Task2/02-病史特点/病史特点-");
//		overlap("CCKS 2017 Task2/04-诊疗经过/诊疗经过-");
//		overlap("CCKS 2017 Task2/05-出院情况/出院情况-");
		
		//判断特征中间是否含有,，。
//		hasDot("CCKS 2017 Task2/01-一般项目/一般项目-");
//		hasDot("CCKS 2017 Task2/02-病史特点/病史特点-");
//		hasDot("CCKS 2017 Task2/04-诊疗经过/诊疗经过-");
//		hasDot("CCKS 2017 Task2/05-出院情况/出院情况-");
		
//		tagBIEO("tag/mergeSplit.txt", "tag/tagBIEO.txt");
		/***********************************************************************************************************************/
		
		
		/******************************************activeLearning  使用Unlabelled的数据，使用之前训练出的模型对unlabled的数据进行打标签，选择效果好的加入到训练集中*******/
//		tag("predictUnlabelHard/predict_", "predictUnlabelHard/tag/unlableTag.txt",426);
//		splitSource.splitNoSpace("activeLearning76/activeLearningUnlabeledTag.txt", "activeLearning76/activeLearningUnlabeledTagSplit.txt","activeLearning76/position.txt");
//		tagBIEO("activeLearning76/activeLearningUnlabeledTagSplit.txt", "activeLearning76/activeLearningUnlabeledTagSplitBIEO.txt");
//		splitSource.splitWithSpace("activeLearning76/activeLearningUnlabeledTagSplit.txt", "activeLearning76/activeLearningUnlabeledTagSplitWithSpace.txt");
		
		/************************************************************************************************************************/
		
//		tag("C:/Users/xyh/Desktop/print/predict_", "C:/Users/xyh/Desktop/print/Tag.txt", 78);
//		tag("output02/cyqk/predict_", "output02/cyqk/cyqkTag.txt", 403);
//		tag("output02/ybxm/predict_", "output02/ybxm/ybxmTag.txt", 158);
//		tag("output02/zljg/predict_", "output02/zljg/zljgTag.txt", 446);

//		splitSource.splitNoSpace("train/mergeAll.txt", "train/mergeAllSplit.txt", "train/mergeAllPosition.txt");
//		tagBIEO("train/mergeAllSplit.txt", "train/mergeAllSplitTagBIEO.txt");
//		splitSource.splitWithSpace("train/mergeAllSplit.txt", "train/mergeAllSplitWithSpace.txt");
	}

	// input路径只用给到文件名编号前一个字符
	// 此函数是对原始文件进行标注，根据标注文件在原始数据中用不同符号标出其所在位置,fileNumber为该目录下文件的数目
	public static void tag(String input, String output,int fileNumber) throws IOException {
		BufferedWriter bWriter = new fileWrite().writeFile(output);
		List<String> list = new ArrayList<>();
		for (int i = 1; i < fileNumber+1; i++) {
			BufferedReader textReader = new fileRead().readFile(input + i + ".txtoriginal.txt");
			BufferedReader bieoReader = new fileRead().readFile(input + i + ".txt");

			String text = textReader.readLine();
			String bieoLine = null;

			System.out.println(i+"\t"+text);
			// 症状和体征用#标注；检查和检验用$标注;病历和诊断用`标注；治疗用&标注；身体部位用@标注
			int offset = 0;// 插入标注符号后原字符串长度会发生变化
			while ((bieoLine = bieoReader.readLine()) != null) {
				String[] bieo = bieoLine.split("\t");
				if (bieo[3].equals("身体部位")) {
					int begin = Integer.parseInt(bieo[1]) + offset;
					int end = Integer.parseInt(bieo[2]) + offset;
					String sub1 = text.substring(0, begin);
					String sub2 = text.substring(begin, end + 1);
					String sub3 = text.substring(end + 1);
					text = sub1 + "@" + sub2 + "@" + sub3;
					offset = offset + 2;
				} else if (bieo[3].equals("症状和体征")) {
					int begin = Integer.parseInt(bieo[1]) + offset;
					int end = Integer.parseInt(bieo[2]) + offset;
					String sub1 = text.substring(0, begin);
					String sub2 = text.substring(begin, end + 1);
					String sub3 = text.substring(end + 1);
					text = sub1 + "#" + sub2 + "#" + sub3;
					offset = offset + 2;
				} else if (bieo[3].equals("检查和检验")) {
					int begin = Integer.parseInt(bieo[1]) + offset;
					int end = Integer.parseInt(bieo[2]) + offset;
					String sub1 = text.substring(0, begin);
					String sub2 = text.substring(begin, end + 1);
					String sub3 = text.substring(end + 1);
					text = sub1 + "$" + sub2 + "$" + sub3;
					offset = offset + 2;
				} else if (bieo[3].equals("疾病和诊断")) {
					int begin = Integer.parseInt(bieo[1]) + offset;
					int end = Integer.parseInt(bieo[2]) + offset;
					String sub1 = text.substring(0, begin);
					String sub2 = text.substring(begin, end + 1);
					String sub3 = text.substring(end + 1);
					text = sub1 + "`" + sub2 + "`" + sub3;
					offset = offset + 2;
				} else if (bieo[3].equals("治疗")) {
					int begin = Integer.parseInt(bieo[1]) + offset;
					int end = Integer.parseInt(bieo[2]) + offset;
					String sub1 = text.substring(0, begin);
					String sub2 = text.substring(begin, end + 1);
					String sub3 = text.substring(end + 1);
					text = sub1 + "&" + sub2 + "&" + sub3;
					offset = offset + 2;
				}
			}
			list.add(text);
		}
		for (String string : list)
			bWriter.write(string + "\n");
		bWriter.close();
	}

	// 判断是否有特征重叠
	// 症状和体征用#标注；检查和检验用$标注;疾病和诊断用`标注；治疗用&标注;身体部位用@标注
	public static void overlap(String input) throws NumberFormatException, IOException {
		int overlapCount = 0;
		// 症状和体征，检查和检验，病历和诊断，治疗，身体部位重叠次数
		int tOverlap = 0, jOverlap = 0, bOverlap = 0, zOverlap = 0, sOverlap = 0;// 症状和体征
		String overlapString = null;
		for (int i = 1; i < 301; i++) {
			BufferedReader bieoReader = new fileRead().readFile(input + i + ".txt");
			String bieoLine = null;
			int lastEnd = 0, startIndex = 0, endIndex = 0;
			if ((bieoLine = bieoReader.readLine()) != null) {
				String[] bieo = bieoLine.split("\t");
				lastEnd = Integer.parseInt(bieo[2]);
			}

			while ((bieoLine = bieoReader.readLine()) != null) {
				String[] bieo = bieoLine.split("\t");
				// 因为文件中的标签都是按从小到大排好序的，所以只需要判断当前标签的起始位置和上一个标签的终止位置是否重叠即可
				startIndex = Integer.parseInt(bieo[1]);
				if (startIndex <= lastEnd) {
					lastEnd = Integer.parseInt(bieo[2]);
					overlapCount++;
					// System.out.println(input + i + "\t" +
					// Integer.parseInt(bieo[1]) + "\t" +
					// Integer.parseInt(bieo[2])
					// + "\t" + bieo[3]+"\n");
					overlapString = bieo[3];
					if (overlapString.equals("症状和体征"))
						tOverlap++;
					else if (overlapString.equals("检查和检验"))
						jOverlap++;
					else if (overlapString.equals("疾病和诊断"))
						bOverlap++;
					else if (overlapString.equals("治疗"))
						zOverlap++;
					else if (overlapString.equals("身体部位"))
						sOverlap++;
					continue;
				} else {
					lastEnd = Integer.parseInt(bieo[2]);
				}
			}
			bieoReader.close();
		}
		System.out.println(input.split("/")[2] + overlapCount);
		String overlapStatistic = "症状和体征-" + tOverlap + "\n" + "检查和检验-" + jOverlap + "\n" + "疾病和诊断" + bOverlap + "\n"
				+ "治疗" + zOverlap + "\n" + "身体部位" + sOverlap + "\n";
		System.out.println(overlapStatistic);
	}

	//判断标注的术语之间是否含有,，。，输出个数 
	public static void hasDot(String input) throws IOException{
		String aline=null;
		int count=0;
		for(int i=1;i<301;i++){
			BufferedReader bReader=new fileRead().readFile(input+ i + ".txt");
			while((aline=bReader.readLine())!=null){
				String term=aline.split("\t")[0];
				if(term.contains(",")||term.contains("。")||term.contains("，")){
					count++;
					System.out.println(input+ i + ".txt"+"\t"+aline);
				}
			}
		}
		System.out.println(count);
	}
	
	// 将tag函数处理完成的文件合并在一起
	public static void mergeFile(String input1, String input2, String input3, String input4, String output)
			throws IOException {
		List<String> list = new ArrayList<>();
		BufferedReader bReader1 = new fileRead().readFile(input1);
		BufferedReader bReader2 = new fileRead().readFile(input2);
		BufferedReader bReader3 = new fileRead().readFile(input3);
		BufferedReader bReader4 = new fileRead().readFile(input4);

		BufferedWriter bWriter = new fileWrite().writeFile(output);
		String aline = null;
		while ((aline = bReader1.readLine()) != null)
			list.add(aline);

		while ((aline = bReader2.readLine()) != null)
			list.add(aline);

		while ((aline = bReader3.readLine()) != null)
			list.add(aline);

		while ((aline = bReader4.readLine()) != null)
			list.add(aline);

		// Collections.shuffle(list);

		for (String string : list) {
			bWriter.write(string.replace(" ", "￥").replace("\t", "￥") + "\n");
		}
		bReader1.close();
		bReader2.close();
		bReader3.close();
		bReader4.close();
		bWriter.close();

	}

	// 症状和体征用#标注；检查和检验用$标注;疾病和诊断用`标注；治疗用&标注;身体部位用^标注
	// 症状和体征用Bt,It,Et,O,St;检查和检验Bj,Ij,Ej,O,Sj;疾病和诊断用Bb,Ib,Eb,O,Sb;治疗用Bz,Iz,Ez,O,Sz
	// 身体部位用Bs,Is,Es,O,Ss
	public static void tagBIEO(String input, String output) throws IOException {
		BufferedReader bReader = new fileRead().readFile(input);
		BufferedWriter bWriter = new fileWrite().writeFile(output);

		List<String> list = new ArrayList<>();
		String aline = null;
		while ((aline = bReader.readLine()) != null) {
			System.out.println(aline);
			String[] words = aline.split("");
			int tFlag = 0, jFlag = 0, bFlag = 0, zFlag = 0, sFlag = 0;
			for (int i = 0; i < words.length; i++) {
				if (words[i].equals("#")) {
					if (words[i + 2].equals("#")) {
						words[i] = "";
						words[i + 1] = "St";
						words[i + 2] = "";
						i = i + 2;
					} else {
						words[i] = "";
						words[i + 1] = "Bt";
						i++;
						tFlag = 1;
					}
				} else if (words[i].equals("$")) {
					if (words[i + 2].equals("$")) {
						words[i] = "";
						words[i + 1] = "Sj";
						words[i + 2] = "";
						i = i + 2;
					} else {
						words[i] = "";
						words[i + 1] = "Bj";
						i++;
						jFlag = 1;
					}
				} else if (words[i].equals("`")) {
					if (words[i + 2].equals("`")) {
						words[i] = "";
						words[i + 1] = "Sb";
						words[i + 2] = "";
						i = i + 2;
					} else {
						words[i] = "";
						words[i + 1] = "Bb";
						i++;
						bFlag = 1;
					}
				} else if (words[i].equals("&")) {
					if (words[i + 2].equals("&")) {
						words[i] = "";
						words[i + 1] = "Sz";
						words[i + 2] = "";
						i = i + 2;
					} else {
						words[i] = "";
						words[i + 1] = "Bz";
						i++;
						zFlag = 1;
					}
				} else if (words[i].equals("@")) {
					if (words[i + 2].equals("@")) {
						words[i] = "";
						words[i + 1] = "Ss";
						words[i + 2] = "";
						i = i + 2;
					} else {
						words[i] = "";
						words[i + 1] = "Bs";
						i++;
						sFlag = 1;
					}
				} else {
					if (tFlag == 1) {
						if (words[i + 1].equals("#")) {
							words[i] = "Et";
							words[i + 1] = "";
							tFlag = 0;
							i++;
						} else {
							words[i] = "It";
						}
					} else if (jFlag == 1) {
						if (words[i + 1].equals("$")) {
							words[i] = "Ej";
							words[i + 1] = "";
							jFlag = 0;
							i++;
						} else {
							words[i] = "Ij";
						}
					} else if (bFlag == 1) {
						if (words[i + 1].equals("`")) {
							words[i] = "Eb";
							words[i + 1] = "";
							bFlag = 0;
							i++;
						} else {
							words[i] = "Ib";
						}
					} else if (zFlag == 1) {
						if (words[i + 1].equals("&")) {
							words[i] = "Ez";
							words[i + 1] = "";
							zFlag = 0;
							i++;
						} else {
							words[i] = "Iz";
						}
					} else if (sFlag == 1) {
						if (words[i + 1].equals("@")) {
							words[i] = "Es";
							words[i + 1] = "";
							sFlag = 0;
							i++;
						} else {
							words[i] = "Is";
						}
					} else {
						words[i] = "O";
					}
				}
			}
			aline = "";
			for (String string : words) {
				if (string.length() == 0) {
					continue;
				} else {
					aline = aline + string + " ";
				}
			}
			aline=aline.replace("I", "I-").replace("B", "B-").replace("E", "E-").replace("S", "S-");
			list.add(aline);
		}
		for (String string : list)
			bWriter.write(string.substring(0, string.length()-1) + "\n");
		bWriter.close();
	}
}
