package splitStringAddSpace;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import fileReadAndWrite.fileRead;
import fileReadAndWrite.fileWrite;

public class splitSource {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		// split("BIEO/bstd.txt", "BIEO/split/bstd.txt");
		// split("BIEO/xyqk.txt", "BIEO/split/xyqk.txt");
		// split("BIEO/ybxm.txt", "BIEO/split/ybxm.txt");
		// split("BIEO/zljg.txt", "BIEO/split/zljg.txt");

		
//		splitNoSpace("tag/merge.txt", "tag/mergeSplit.txt");
//		splitWithSpace("tag/mergeSplit.txt", "tag/mergeSplitWithSpace.txt");
		
		
//		splitWithSpace("unlabeled-1/merge/merge.txt", "unlabeled-1/merge/mergeSplitWithSpace.txt");
		
//		splitNoSpace("CCKS 2017 Task2/test dataset/merge/split/zljg/zljgSentence.txt", "CCKS 2017 Task2/test dataset/merge/split/zljg/zljgSentenceSplit.txt", "CCKS 2017 Task2/test dataset/merge/split/zljg/zljgSentencePosition.txt");
//		splitWithSpace("CCKS 2017 Task2/test dataset/merge/split/bstd/bstdSentenceSplit.txt", "CCKS 2017 Task2/test dataset/merge/split/bstd/bstdSentenceSplitWithSpace.txt");
		
//		splitNoSpace("CCKS 2017 Task2/test dataset/merge/all/bstd.txt", "CCKS 2017 Task2/test dataset/merge/all/dotsplit/bstd/bstdSplitWithDot.txt", "CCKS 2017 Task2/test dataset/merge/all/dotsplit/bstd/bstdusedotPosition.txt");
//		splitWithSpace("CCKS 2017 Task2/test dataset/merge/all/dotsplit/bstd/bstdSplitWithDot.txt", "CCKS 2017 Task2/test dataset/merge/all/dotsplit/bstd/bstdSplitWithDotWithSpace.txt");
//	
//		splitNoSpace("CCKS 2017 Task2/test dataset/merge/all/cyqk.txt", "CCKS 2017 Task2/test dataset/merge/all/dotsplit/cyqk/cyqkSplitWithDot.txt", "CCKS 2017 Task2/test dataset/merge/all/dotsplit/cyqk/cyqkusedotPosition.txt");
//		splitWithSpace("CCKS 2017 Task2/test dataset/merge/all/dotsplit/cyqk/cyqkSplitWithDot.txt", "CCKS 2017 Task2/test dataset/merge/all/dotsplit/cyqk/cyqkSplitWithDotWithSpace.txt");
//		
//		splitNoSpace("CCKS 2017 Task2/test dataset/merge/all/ybxm.txt", "CCKS 2017 Task2/test dataset/merge/all/dotsplit/ybxm/ybxmSplitWithDot.txt", "CCKS 2017 Task2/test dataset/merge/all/dotsplit/ybxm/ybxmusedotPosition.txt");
//		splitWithSpace("CCKS 2017 Task2/test dataset/merge/all/dotsplit/ybxm/ybxmSplitWithDot.txt", "CCKS 2017 Task2/test dataset/merge/all/dotsplit/ybxm/ybxmSplitWithDotWithSpace.txt");
//		
//		splitNoSpace("CCKS 2017 Task2/test dataset/merge/all/zljg.txt", "CCKS 2017 Task2/test dataset/merge/all/dotsplit/zljg/zljgSplitWithDot.txt", "CCKS 2017 Task2/test dataset/merge/all/dotsplit/zljg/zljgusedotPosition.txt");
//		splitWithSpace("CCKS 2017 Task2/test dataset/merge/all/dotsplit/zljg/zljgSplitWithDot.txt", "CCKS 2017 Task2/test dataset/merge/all/dotsplit/zljg/zljgSplitWithDotWithSpace.txt");
		
		maxLength("CCKS 2017 Task2/test dataset/merge/all/dotsplit/zljg/zljgSplitWithDot.txt");
		maxLength("CCKS 2017 Task2/test dataset/merge/all/dotsplit/ybxm/ybxmSplitWithDot.txt");
		maxLength("CCKS 2017 Task2/test dataset/merge/all/dotsplit/cyqk/cyqkSplitWithDot.txt");
		maxLength("CCKS 2017 Task2/test dataset/merge/all/dotsplit/bstd/bstdSplitWithDot.txt");

	}

	// 每个字符不用空格分开
	public static void splitNoSpace(String input, String output,String sentencePositonFile) throws IOException {
		BufferedReader bReader = new fileRead().readFile(input);
		BufferedWriter bWriter = new fileWrite().writeFile(output);
		BufferedWriter pWriter=new fileWrite().writeFile(sentencePositonFile);
		
		int i=1,j=1;//i为第i个句子，j为第i个句子分割后的第j个短句
		List<String> list = new ArrayList<>();
		String aline = null;// 不用空格分开
		while ((aline = bReader.readLine()) != null) {
			String[] terms = aline.split("。", -1);//用逗号分割的时候改这里
			j=1;
			for (String term : terms) {
				term = term.replace("\t", "￥").replace(" ", "￥");
				if (term.length() != 0){
					list.add(term);
					pWriter.write(i+"-"+j+"-"+term.length()+"\n");
					j++;
				}
				else {
					continue;
				}
			}
			i++;
		}

//		Collections.shuffle(list);// 随机打乱

		for (String string : list) {
			
			bWriter.write(string + "\n");
		}
		pWriter.close();
		bReader.close();
		bWriter.close();
	}

	// 每个字符用空格分开
	public static void splitWithSpace(String input, String output) throws IOException {
		BufferedReader bReader = new fileRead().readFile(input);
		BufferedWriter bWriter = new fileWrite().writeFile(output);

		String aline = null;// 用空格分开
		int i = 1, max = 0;
		while ((aline = bReader.readLine()) != null) {
			i = 1;
			aline = aline.replace("#", "").replace("$", "").replace("`", "").replace("&", "").replace("@", "");
			String[] items = aline.split("");
			aline = "";
			for (String item : items) {
				i++;
				aline = aline + item + " ";
			}
			if (max < i)
				max = i;
			bWriter.write(aline.substring(0, aline.length()-1) + "\n");
		}
		System.out.println(max);
		bWriter.close();
	}
	
	//统计最长字符串
	public static void maxLength(String input) throws IOException{
		BufferedReader bReader=new fileRead().readFile(input);
		String aline=null;
		int length=0;
		while((aline=bReader.readLine())!=null){
			if(aline.length()>length)
				length=aline.length();
		}
		System.out.println(length);
		bReader.close();
	}
}
