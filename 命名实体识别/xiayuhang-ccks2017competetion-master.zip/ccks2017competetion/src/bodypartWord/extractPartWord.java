package bodypartWord;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;

import fileReadAndWrite.fileRead;
import fileReadAndWrite.fileWrite;

//从标注数据中抽取出部位词
public class extractPartWord {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		ArrayList<String> bodyPart = new ArrayList<>();
		String yibanxiangmu = "trainingset-1-100/01-一般项目1-100-1-1/";
		String bingshitedian = "trainingset-1-100/02-病史特点1-100-1-1/";
		String zhenliaoguocheng = "trainingset-1-100/04-诊疗经过1-100-1-1/";
		String chuyuanqingkuang = "trainingset-1-100/05-出院情况1-100-1-1/";

		for (int i = 1; i < 101; i++) {
			BufferedReader yReader = new fileRead().readFile(yibanxiangmu + "一般项目-" + i + ".txt");
			String aline = null;
			while ((aline = yReader.readLine()) != null) {
				String[] terms = aline.split("\t");
				if (terms[3].equals("治疗")) {
					if (bodyPart.contains(terms[0]))
						continue;
					else {
						bodyPart.add(terms[0]);
					}
				}
			}
			yReader.close();
		}

		for (int i = 1; i < 101; i++) {
			BufferedReader bReader = new fileRead().readFile(bingshitedian + "病史特点-" + i + ".txt");
			String aline = null;
			while ((aline = bReader.readLine()) != null) {
				String[] terms = aline.split("\t");
				if (terms[3].equals("治疗")) {
					if (bodyPart.contains(terms[0]))
						continue;
					else {
						bodyPart.add(terms[0]);
					}
				}
			}
			bReader.close();
		}

		for (int i = 1; i < 101; i++) {
			BufferedReader zReader = new fileRead().readFile(zhenliaoguocheng + "诊疗经过-" + i + ".txt");
			String aline = null;
			while ((aline = zReader.readLine()) != null) {
				String[] terms = aline.split("\t");
				if (terms[3].equals("治疗")) {
					if (bodyPart.contains(terms[0]))
						continue;
					else {
						bodyPart.add(terms[0]);
					}
				}
			}
			zReader.close();
		}

		for (int i = 1; i < 101; i++) {
			BufferedReader cReader = new fileRead().readFile(chuyuanqingkuang + "出院情况-" + i + ".txt");
			String aline = null;
			while ((aline = cReader.readLine()) != null) {
				String[] terms = aline.split("\t");
				if (terms[3].equals("治疗")) {
					if (bodyPart.contains(terms[0]))
						continue;
					else {
						bodyPart.add(terms[0]);
					}
				}
			}
			cReader.close();
		}

		BufferedWriter bWriter = new fileWrite().writeFile("result/treat.txt");
		for (String item : bodyPart)
			bWriter.write(item + "\n");
		bWriter.close();

	}

}
