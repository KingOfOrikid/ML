package pretreatment;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import fileReadAndWrite.fileRead;
import fileReadAndWrite.fileWrite;

public class cutLongCentence {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader bReader = new fileRead().readFile("CCKS 2017 Task2/test dataset/merge/split/zljg/zljgSplit.txt");
		BufferedWriter lineNumberWriter = new fileWrite()
				.writeFile("CCKS 2017 Task2/test dataset/merge/split/zljg/line.txt");
		BufferedWriter bWriter = new fileWrite()
				.writeFile("CCKS 2017 Task2/test dataset/merge/split/zljg/zljgSentence.txt");
		String aLine = null;
		int i = 1;
		while ((aLine = bReader.readLine()) != null) {
			if (aLine.length() > 185) {
				lineNumberWriter.write(i + "\n");
				bWriter.write(aLine + "\n");
			}
			i++;
		}
		bWriter.close();
		lineNumberWriter.close();
	}
}
