package pretreatment;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import fileReadAndWrite.fileRead;
import fileReadAndWrite.fileWrite;

/**
 * @author 夏宇航 xiayuhang_ecust@qq.com:
 * @version 创建时间：2017年6月28日 下午4:47:09 将未标注数据中的html元素都替换为空字符
 */
public class ReplaceHtmlElement {

	public static void main(String[] args) throws IOException {
		File dir = new File("unlabeled-2/诊疗经过");
		 for(File file:dir.listFiles()){
		 replaceHtmlElement(file.getAbsolutePath());
		 }
	}

	public static void replaceHtmlElement(String filePath) throws IOException {
		BufferedReader bReader = new fileRead().readFile(filePath);
		String aline = null;
		String[] reg = { 
				"mso-ascii-mso-hansi-mso-bidi-mso-bidi-font-size:12.0pt;",
				"mso-bidi-mso-ascii-mso-hansi-mso-bidi-font-size:12.0pt;", 
				"mso-ascii- mso-hansi- mso-bidi- mso-font-kerning: 1.0pt;",
				"spanlang==spanlang==，font-size:13.5pt;",
				"spanmso-hansi-font-family:TimesNewRoman;",
				"spanlang==mso-bidi-font-size:12.0pt;",
				"BP190/120mmHgspan=font-family:宋体;", 
				"mso-ascii-font-family:TimesNewRoman;",
				"mso-hansi-font-family:TimesNewRoman;'",
				"mso-hansi-font-family:TimesNewRoman;",
				"mso-bidi-font-family:TimesNewRoman;'",
				"=mso-bidi-font-family:TimesNewRoman;'",
				"=mso-bidi-font-family:TimesNewRoman;",
				"mso-hansi-font-family:楷体_GB2312;",
				"mso-ascii-font-family:楷体_GB2312;'",
				"fmso-ascii-mso-hansi-mso-bidi-",
				"spanlang==mso-ansi-language:;",
				"mso-bidi-mso-ascii-mso-hansi-",
				"mso-ascii-mso-hansi-mso-bidi-",
				"mso-ascii-mso-hansi-mso-bidi-",
				"mso-fareast-font-family: 宋体;", 
				"mso-fareast-language: ZH-CN;", 
				"mso-bidi-font-family: 宋体;", 
				"background-:rgb(255,255,255);",
				"mso-bidi-font-size: 10.5pt;",
				"mso-bidi-font-size:14.0pt;",
				"mso-font-kerning: 1.0pt;", 
				"mso-bidi-language: AR-SA;",
				"fontface=TimesNewRoman",
				"mso-bidi-font-size:12.0pt;", 
				"span  font-family: 宋体;",
				"spanfont-family:宋体;",
				"span=font-family:宋体;",
				"font-family: Helvetica;", 
				"color: rgb(51, 51, 51);",
				"style=&quot;", "EN-US",
				"color", "style=&quot;",
				"span=font-family:宋体;",
				"spanfont-family:宋体;",
				"mso-ansi-language: ;",
				"font-size: 10.5pt;",
				"pline-height:24px;",
				"mso-ansi-language:;",
				"mso-ansi-language:;",
				"'font-family:宋体;",
				"text-indent:32px;",
				"'font-family:宋体；",
				"font-family:宋体;",
				"font-family:宋体；",
				"font-family:楷体_GB2312;",
				"text-indent:24pt;",
				"font-size:13.5pt;",
				"line-height:24px;",
				"font-size:13pt;",
				"font-size:12pt;",
				"font-size:10pt;",
				"font-size:13px;",
				"fontsize=2",
				"fontsize=3",
				"span lang=&quot;",
				"mso-bidi-'",
				"spanlang==", 
				"&rdquo;", 
				"&ldquo;", 
				"/font", 
				"span=",
				"/span",
				"span",
				"&amp;", 
				"&deg;",
				"style", 
				"nbsp;",
				"&quot;", 
				"&gt;", 
				"&lt;",
				"/p",
				"=",
				"font.*?;",
				":rgb.*?;",
				"font[\\w]*#[\\d]*",
				"mso[A-Za-z-][A-Za-z-]*",
				"Tmso.*?;",
				"mso.*?;",
				"&.*?;",
				"Mso.*?;"
				};
		
		ArrayList<String> list = new ArrayList<>();
		while ((aline = bReader.readLine()) != null) {
			for (String aString : reg) {
				System.out.println(aString);
//				aline = aline.replace(aString, "");
				Pattern pattern=Pattern.compile(aString);
				Matcher matcher=pattern.matcher(aline);
				aline=matcher.replaceAll("");
			}
			aline = aline.replace(" ", "");
			list.add(aline);
		}
		bReader.close();
		BufferedWriter bWriter = new fileWrite().writeFile(filePath);
		for (String a : list)
			bWriter.write(a + "\n");
		bWriter.close();
	}

}
