package wangqidaima;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.List;

/**
 * 将用“##”包围的症状，转换成“\t症状[startIndex,endIndex+1]”
 * 
 * @author apple
 *
 */
public class NewTransferSymptomLabeled {

	// public static final String root =
	// "F:/大学/实验室/医疗信息抽取/newTest/症状切分7-21/应用句法分析/人工标注/";
	public static final String root = "D:/王祺/症状标注/EMR统合/";
	// public static final String root = "H:/王祺/症状标注/按逗号/";
	// public static final String pathInputRawText = root+"testdata.txt";
	// public static final String pathInputHumanLabeledText = root+"蔡正合并.txt";
	// public static final String pathOutputText = root+"蔡正合并_labeled.txt";
	// public static final String pathInputHumanLabeledText =
	// root+"EMRdata_human_new.txt";
	// public static final String pathOutputText =
	// root+"EMRdata_labeled_new.txt";

	public static final String pathInputHumanLabeledText = root + "测试数据_human.txt";
	public static final String pathOutputText = root + "测试数据_labeled.txt";
	// public static final String pathInputHumanLabeledText =
	// root+"测试数据_labeled_humanFormat.txt";
	// public static final String pathOutputText =
	// root+"新测试数据_distantLabeled.txt";
	// public static final String pathInputHumanLabeledText =
	// root+"测试数据_labeled_humanFormat_douhao.txt";
	// public static final String pathOutputText =
	// root+"新测试数据_distantLabeled_douhao.txt";
	// public static final String root = "D:/王祺/症状标注/百科标注/";
	// public static final String pathInputHumanLabeledText =
	// root+"test_humanLabeled.txt";
	// public static final String pathOutputText = root+"test_labeled.txt";
	// public static final String pathInputHumanLabeledText =
	// root+"trainAll_labeled_humanFormat.txt";
	// public static final String pathOutputText =
	// root+"trainAll_distantLabeled.txt";

	// public static final String pathInputReplaceKeyValues = root +
	// "replace.txt";
	// public static final String pathInputNotSymptom = root + "notSymptom.txt";
	public static final String pathInputReplaceKeyValues = "";
	public static final String pathInputNotSymptom = "";

	static List<ReplaceKeyValue> listReplaceKeyValues;
	static List<String> listNotSymptom;

	// static String strPattern="##(.+?)##";

	public static void main(String[] args) {
		// TODO 自动生成的方法存根
		print();
		// String str="##as##d";
		// String[] s=str.split("##");
		// Gson gson=new Gson();
		// System.out.println(gson.toJson(s));
	}

	public static void print() {
		String path = pathOutputText;
		path = path.replaceAll("/[^/]+$", "");
		File file = new File(path);
		if (!file.exists()) {
			file.mkdirs();
		}

		String lineRaw = null;
		String lineHuman = null;
		try {
			// BufferedReader inRaw = new BufferedReader(new
			// InputStreamReader(new
			// FileInputStream(pathInputRawText),"UTF-8"));;
			BufferedReader inHuman = new BufferedReader(
					new InputStreamReader(new FileInputStream(pathInputHumanLabeledText), "UTF-8"));
			;

			PrintWriter out = new PrintWriter(
					new BufferedWriter(new OutputStreamWriter(new FileOutputStream(pathOutputText, false), "UTF-8")));

			// lineRaw=inRaw.readLine();
			lineHuman = inHuman.readLine();

			while (lineHuman != null && !lineHuman.equals("")) {

				lineRaw = lineHuman.replace("##", "");

				out.print(lineRaw);

				String[] arrayStr = lineHuman.split("##");

				int beginIndex = 0;
				boolean isSymptom = false;

				for (String str : arrayStr) {
					if (isSymptom) {
						String symptom = str;
						out.print("\t" + symptom + "[" + beginIndex + "," + (beginIndex + symptom.length()) + "]");
					}
					beginIndex += str.length();
					isSymptom = !isSymptom;
				}

				// Pattern pattern=Pattern.compile(strPattern);
				// Matcher matcher=pattern.matcher(lineHuman);
				// while(matcher.find()){
				// String symptom=matcher.group(1);
				//
				//
				// int beginIndex;
				// if((beginIndex=lineRaw.indexOf(symptom,fromIndex))!=-1){
				// out.print("\t"+symptom+"["+beginIndex+","+(beginIndex+symptom.length())+"]");
				//
				// fromIndex=beginIndex+symptom.length();
				// }
				// }

				out.println();

				// lineRaw=inRaw.readLine();
				lineHuman = inHuman.readLine();
			}
			// inRaw.close();
			inHuman.close();
			out.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("file not exist!");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

class ReplaceKeyValue {

	String key;
	String value;

	public ReplaceKeyValue(String key, String value) {
		super();
		this.key = key;
		this.value = value;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
