package wangqidaima;
import java.util.List;

public class Content {

	public String sentence;
	List<Symptom> listSymptoms;

	public Content(String sentence, List<Symptom> listSymptoms) {
		super();
		this.sentence = sentence;
		this.listSymptoms = listSymptoms;
	}

	public String getSentence() {
		return sentence;
	}

	public void setSentence(String sentence) {
		this.sentence = sentence;
	}

	public List<Symptom> getListSymptoms() {
		return listSymptoms;
	}

	public void setListSymptoms(List<Symptom> listSymptoms) {
		this.listSymptoms = listSymptoms;
	}

}
