package wangqidaima;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import fileReadAndWrite.fileRead;
import fileReadAndWrite.fileWrite;

public class disorganize {

	// 将文件中字符串顺序随机打乱
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader bReader = new fileRead().readFile("BIEO/split/origin.txt");
		BufferedWriter bWriter = new fileWrite().writeFile("BIEO/split/originWithoutSpaceDisorganise.txt");

		String line = null;
		List<String> list = new ArrayList<>();
		while ((line = bReader.readLine()) != null) {
			list.add(line);
		}

		Collections.shuffle(list);

		for (String aline : list) {
			bWriter.write(aline + "\n");
		}

		bWriter.close();

	}

}
