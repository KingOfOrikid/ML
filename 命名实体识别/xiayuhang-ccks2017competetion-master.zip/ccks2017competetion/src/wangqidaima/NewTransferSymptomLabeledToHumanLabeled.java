package wangqidaima;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class NewTransferSymptomLabeledToHumanLabeled {

	// public static final String root = "F:/大学/实验室/医疗信息抽取/测试数据/";
	// public static final String pathInput = root+"testDataWithoutOneChar.txt";
	// public static final String pathOutput =
	// root+"testByHumanWithoutOneChar.txt";
	// public static final String root = "F:/Users/apple/Desktop/2016_12_28/";
	// public static final String pathInput =
	// root+"corpus_NOqingkuang_by_sentence_norepeat_match.txt";
	// public static final String pathOutput = root+"EMRdata.txt";

	// public static final String root = "H:/实验室/语料自动标注结果/";
	// public static final String pathInput =
	// root+"corpus_现病史_bysentence_删减后-distant.txt";
	// public static final String pathOutput = root+"EMRdata.txt";

	// public static final String root = "H:/王祺/症状标注/";
	// public static final String root = "D:/王祺/症状标注/EMR统合/";
	// public static final String pathInput = root+"标注（程序修改后）.txt";
	// public static final String pathOutput = root+"EMRdata.txt";
	// public static final String pathInput = root+"EMRdata_labeled_new.txt";
	// public static final String pathOutput = root+"EMRdata_human_new.txt";
	// public static final String pathInput = root+"测试数据_distant.txt";
	// public static final String pathOutput =
	// root+"测试数据_labeled_humanFormat.txt";

	public static final String root = "D:/王祺/症状标注/百科标注/";
	public static final String pathInput = root + "trainAll_distant.txt";
	public static final String pathOutput = root + "trainAll_labeled_humanFormat.txt";

	// static final String charSplitLeft="[{";
	// static final String charSplitRight="}]";
	static final String charSplitLeft = "##";
	static final String charSplitRight = "##";
	static int intOffset = charSplitLeft.length() + charSplitRight.length();

	public static void main(String[] args) {
		// TODO 自动生成的方法存根
		print();
	}

	public static void print() {

		String path = pathOutput;
		path = path.replaceAll("/[^/]+$", "");
		File file = new File(path);
		if (!file.exists()) {
			file.mkdirs();
		}

		String line = null;
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(pathInput), "UTF-8"));
			;
			PrintWriter out = new PrintWriter(
					new BufferedWriter(new OutputStreamWriter(new FileOutputStream(pathOutput, false), "UTF-8")));

			line = in.readLine();
			while (line != null && !line.equals("")) {

				// String[] str=line.split("\t");
				// String keShi=str[0];
				// line=line.substring(keShi.length()+1);
				String strTransfer = getStrTransfer(line);

				// String strTransfer=getStrTransfer(line);

				out.println(strTransfer);

				line = in.readLine();
			}

			in.close();
			out.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("file not exist!");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static String getStrTransfer(String line) {
		Content content;

		if (line.contains("\t")) {
			List<Symptom> listSymptoms = new ArrayList<Symptom>();////

			String[] str = line.split("\t");

			String sentence = str[0];////
			for (int i = 1; i < str.length; i++) {
				// String sentence=str[0]+"\t"+str[1];////
				// for(int i=2;i<str.length;i++){

				str[i] = str[i].replace("]", "");
				String[] strTmp = str[i].split("\\[");
				String strSymptom = strTmp[0];////
				String[] strIndex = strTmp[1].split(",");
				int startIndex = Integer.parseInt(strIndex[0]);////
				int endIndex = Integer.parseInt(strIndex[1]);////
				// endIndex = endIndex - 1;// 读入文件就是这样
				Symptom symptom = new Symptom(strSymptom, startIndex, endIndex);
				listSymptoms.add(symptom);
			}
			content = new Content(sentence, listSymptoms);
		} else {
			List<Symptom> listSymptoms = new ArrayList<Symptom>();////
			String sentence = line;////
			content = new Content(sentence, listSymptoms);
		}

		String strTransfer = transfer(content);

		return strTransfer;
	}

	public static String transfer(Content content) {
		int offset = 0;

		String sent1, sent2, sent3;

		String sentence = content.getSentence();
		List<Symptom> listSymptoms = content.getListSymptoms();

		for (Symptom symptom : listSymptoms) {
			int startIndex = symptom.getStartIndex() + offset;
			int endIndex = symptom.getEndIndex() + offset;
			sent1 = sentence.substring(0, startIndex);
			sent2 = sentence.substring(startIndex, endIndex + 1);
			sent3 = sentence.substring(endIndex + 1);

			sentence = sent1 + charSplitLeft + sent2 + charSplitRight + sent3;

			offset = offset + intOffset;
		}

		return sentence;
	}

}
