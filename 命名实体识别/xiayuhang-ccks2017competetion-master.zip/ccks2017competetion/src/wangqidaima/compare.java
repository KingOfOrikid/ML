package wangqidaima;
import java.io.BufferedReader;
import java.io.IOException;

import fileReadAndWrite.fileRead;

//比较两个文件中字符串的长度是否都相同
public class compare {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader bReader = new fileRead().readFile("tag/mergeSplitWithSpace.txt");
		BufferedReader bReader2 = new fileRead().readFile("tag/tagBIEO.txt");

		String line1 = null;
		String line2 = null;
		while ((line1 = bReader.readLine()) != null && (line2 = bReader2.readLine()) != null) {
			String[] terms1 = line1.split(" ");
			String[] terms2 = line2.split(" ");
			if (terms1.length != terms2.length) {
				System.out.println(line2);
			}
		}
	}

}
