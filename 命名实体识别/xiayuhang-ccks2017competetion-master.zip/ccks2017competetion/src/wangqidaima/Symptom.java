package wangqidaima;
public class Symptom {

	public String symptom;
	public int startIndex;
	public int endIndex;

	public Symptom(String symptom, int startIndex, int endIndex) {
		super();
		this.symptom = symptom;
		this.startIndex = startIndex;
		this.endIndex = endIndex;
	}

	public String getSymptom() {
		return symptom;
	}

	public void setSymptom(String symptom) {
		this.symptom = symptom;
	}

	public int getStartIndex() {
		return startIndex;
	}

	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}

	public int getEndIndex() {
		return endIndex;
	}

	public void setEndIndex(int endIndex) {
		this.endIndex = endIndex;
	}

	@Override
	public String toString() {
		String str = symptom + "[" + startIndex + "," + (endIndex + 1) + "]";
		return str;
	}
}
