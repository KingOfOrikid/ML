package postTreatment;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;

import fileReadAndWrite.fileRead;
import fileReadAndWrite.fileWrite;

public class replaceLongSentence {

	//输入input为长句子所在行数的文件路径,如bstdline.txt,longSentencePath为长句子文件路径，如bstdSentenceresult.txt
	public static void replace(String input,String longSentencePath) throws IOException{
		BufferedReader bReader=new fileRead().readFile(input);
		BufferedReader lReader=new fileRead().readFile(longSentencePath);
		String aline=null;
		String folder=input.split("/")[input.split("/").length-1];
		String folderName=null;
		if(folder.contains("bstd")){
			folderName="output02/bstd";
		}else if(folder.contains("cyqk")){
			folderName="output02/cyqk";
		}else if(folder.contains("ybxm")){
			folderName="output02/ybxm";
		}else if(folder.contains("zljg")){
			folderName="output02/zljg";
		}
		while((aline=bReader.readLine())!=null){
			//将原文件夹下的内容覆盖掉
			BufferedWriter bWriter=new fileWrite().writeFile(folderName+"/predict_"+aline+".txt");
			String longSentence=lReader.readLine();
			longSentence=longSentence.split(",")[2];
			longSentence=longSentence.replace(" ", "\t").replace(";", "\n").replace("\n\n", "");
			bWriter.write(longSentence);
			bWriter.close();
		}
		bReader.close();
		lReader.close();
	}
}
