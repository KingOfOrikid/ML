/**
 * 
 */
package postTreatment;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import fileReadAndWrite.fileRead;
import fileReadAndWrite.fileWrite;

/** 
* @author 作者 E-mail: 153996626@qq.com
* @version 创建时间：2017年7月2日 下午5:18:34 
* 将预测结果还原为比赛要求的结果格式
*/
/**
 * @author hql
 *
 */
public class SentenceRestore {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
//		replaceLongSentence.replace("output02/bstdline.txt", "output02/bstdSentenceresult.txt");
//		replaceLongSentence.replace("output02/cyqkline.txt", "output02/cyqkSentenceresult.txt");
//		replaceLongSentence.replace("output02/ybxmline.txt", "output02/ybxmSentenceresult.txt");
//		replaceLongSentence.replace("output02/zljgline.txt", "output02/zljgSentenceresult.txt");
		
		Restore("output/bstdPosition.txt", "output/bstd/predict_", "output/result/bstdresult.txt");
		Restore("output/cyqkPosition.txt", "output/cyqk/predict_", "output/result/cyqkresult.txt");
		Restore("output/ybxmPosition.txt", "output/ybxm/predict_", "output/result/ybxmresult.txt");
		Restore("output/zljgPosition.txt", "output/zljg/predict_", "output/result/zljgresult.txt");
		
//		Restore("CCKS 2017 Task2/test dataset/merge/bstdSentencePosition.txt", "output02/bstdSentence/predict_", "output02/bstdSentenceresult.txt");
//		Restore("CCKS 2017 Task2/test dataset/merge/zljgSentencePosition.txt", "output02/zljgSentence/predict_", "output02/zljgSentenceresult.txt");
	}

	// inpu只用给到文件名编号前一个字符
	// 将预测结果恢复成答案要求格式：301,一般项目,右髋部 21 23 身体部位;疼痛 27 28 症状和体征;肿胀 29 30 症状和体征;
	public static void Restore(String positionFile, String input, String output) throws IOException {
		BufferedWriter bWriter = new fileWrite().writeFile(output);
		List<String> textList = new ArrayList<>();
		String aLine = null;
		BufferedReader positionReader = new fileRead().readFile(positionFile);
		while ((aLine = positionReader.readLine()) != null) {
			textList.add(aLine);
		}
		int lineNumber = 1;// 指示当前处理到第几行，即a-b中的a
		int currentLineNumber = 0;
		int sentenceLength = 0;// 句子长度
		int FileNumber = 1;
		int LineNum=currentLineNumber+301;
		int plus=300;
		String lineHead=null;//行首
		if(positionFile.split("/")[1].contains("bstd"))
			lineHead="病史特点";
		else if(positionFile.split("/")[1].contains("cyqk")){
			lineHead="出院情况";
		}
		else if(positionFile.split("/")[1].contains("ybxm")){
			lineHead="一般项目";
		}
		else if(positionFile.split("/")[1].contains("zljg")){
			lineHead="诊疗经过";
		}
		bWriter.write(LineNum+","+lineHead+",");
		for (String line : textList) {
			System.out.println(line);
			currentLineNumber = Integer.parseInt(line.split("-")[0]);
			if (currentLineNumber == lineNumber) {
				BufferedReader bieoReader = new fileRead().readFile(input + FileNumber + ".txt");
				FileNumber++;
				String bieoString = null;
				while ((bieoString = bieoReader.readLine()) != null) {
					String[] terms = bieoString.split("\t");
					int begin = Integer.parseInt(terms[1]) + sentenceLength;
					int end = Integer.parseInt(terms[2]) + sentenceLength;
					bWriter.write(terms[0] + " " + begin + " " + end + " " + terms[3] + ";");
				}
				sentenceLength = sentenceLength + Integer.parseInt(line.split("-")[2]) + 1;//加1是因为原始数据是用句号隔开的，句号被删除了，还原的时候要加上被删除的句号的长度
			} else {
				if(positionFile.split("/")[1].contains("cyqk")||positionFile.split("/")[1].contains("zljg")){
					if(currentLineNumber==61){
						plus=plus+1;
						LineNum=currentLineNumber+plus;
						bWriter.write("\n"+LineNum+","+lineHead+",");
						lineNumber = currentLineNumber;
						sentenceLength = 0;
						BufferedReader bieoReader = new fileRead().readFile(input + FileNumber + ".txt");
						FileNumber++;
						String bieoString = null;
						while ((bieoString = bieoReader.readLine()) != null) {
							String[] terms = bieoString.split("\t");
							int begin = Integer.parseInt(terms[1]) + sentenceLength;
							int end = Integer.parseInt(terms[2]) + sentenceLength;
							bWriter.write(terms[0] + " " + begin + " " + end + " " + terms[3] + ";");
						}
						sentenceLength = sentenceLength + Integer.parseInt(line.split("-")[2]) + 1;
					}else {
						LineNum=currentLineNumber+plus;
						bWriter.write("\n"+LineNum+","+lineHead+",");
						lineNumber = currentLineNumber;
						sentenceLength = 0;
						BufferedReader bieoReader = new fileRead().readFile(input + FileNumber + ".txt");
						FileNumber++;
						String bieoString = null;
						while ((bieoString = bieoReader.readLine()) != null) {
							String[] terms = bieoString.split("\t");
							int begin = Integer.parseInt(terms[1]) + sentenceLength;
							int end = Integer.parseInt(terms[2]) + sentenceLength;
							bWriter.write(terms[0] + " " + begin + " " + end + " " + terms[3] + ";");
						}
						sentenceLength = sentenceLength + Integer.parseInt(line.split("-")[2]) + 1;
					}
				}else {
					LineNum=currentLineNumber+300;
					bWriter.write("\n"+LineNum+","+lineHead+",");
					lineNumber = currentLineNumber;
					sentenceLength = 0;
					BufferedReader bieoReader = new fileRead().readFile(input + FileNumber + ".txt");
					FileNumber++;
					String bieoString = null;
					while ((bieoString = bieoReader.readLine()) != null) {
						String[] terms = bieoString.split("\t");
						int begin = Integer.parseInt(terms[1]) + sentenceLength;
						int end = Integer.parseInt(terms[2]) + sentenceLength;
						bWriter.write(terms[0] + " " + begin + " " + end + " " + terms[3] + ";");
					}
					sentenceLength = sentenceLength + Integer.parseInt(line.split("-")[2]) + 1;
				}
				
			}
		}
		bWriter.close();
	}

}
